package com.pulse.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private var panel: View? = null
    private var cross: CrosshairView? = null
    private var crossLp: WindowManager.LayoutParams? = null

    private var crossOn = false
    private var crossSize = 40
    private var colorIdx = 0
    private val colors = intArrayOf(Color.WHITE, Color.GREEN, Color.RED, Color.CYAN, Color.YELLOW, 0xFFB388FF.toInt())

    private var running = false
    private var startMs = 0L
    private var elapsed = 0L
    private var timeText: TextView? = null

    // Screen effects: drawn by this app over the game (they really work)
    private var fx: ScreenFxView? = null
    private var tintIdx = 0
    private val tintColors = intArrayOf(
        0xFFB388FF.toInt(), 0xFF40C4FF.toInt(), 0xFFFF5252.toInt(),
        0xFF69F0AE.toInt(), 0xFFFFD740.toInt(), 0xFFFF80AB.toInt()
    )

    private var currentTab = 0 // 0=Visual, 1=Combat, 2=Misc, 3=Settings

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpF(v: Float) = v * resources.displayMetrics.density

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun addFx() {
        val v = ScreenFxView(this)
        v.visibility = View.GONE
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        fx = v
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addFx()
        addBubble()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("velka", "Velka Visual", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "velka")
            .setContentTitle("Velka Visual is running")
            .setContentText("Overlay active over Minecraft")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun overlayParams(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
    }

    // ---------- Floating bubble with cat avatar ----------
    private fun addBubble() {
        val size = dp(58)
        val lp = overlayParams(size, size, true).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14); y = dp(130)
        }
        val v = ImageView(this).apply {
            setImageResource(R.drawable.avatar_cat)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, o: Outline) {
                    o.setOval(0, 0, view.width, view.height)
                }
            }
            clipToOutline = true
            elevation = dp(8).toFloat()
            // subtle ring
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0xFFB388FF.toInt())
            }
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY; moved = false
                    view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 8 || abs(my) > 8) moved = true
                    if (moved) {
                        lp.x = sx + mx; lp.y = sy + my
                        wm.updateViewLayout(view, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(v, lp)
        bubble = v
    }

    // ---------- Panel toggle with smooth animation ----------
    private fun togglePanel() {
        val p = panel
        if (p != null) {
            // hide animation
            p.animate()
                .alpha(0f)
                .scaleX(0.85f)
                .scaleY(0.85f)
                .setDuration(180)
                .setInterpolator(DecelerateInterpolator())
                .setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        try { wm.removeView(p) } catch (_: Exception) {}
                        panel = null
                        timeText = null
                    }
                })
                .start()
            return
        }
        val v = buildPanel()
        val width = dp(390)
        val lp = overlayParams(width, WindowManager.LayoutParams.WRAP_CONTENT, true)
            .apply { gravity = Gravity.CENTER }
        v.alpha = 0f
        v.scaleX = 0.85f
        v.scaleY = 0.85f
        wm.addView(v, lp)
        panel = v
        v.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(220)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    private fun roundedBg(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (strokeW > 0) setStroke(strokeW, strokeColor)
        }
    }

    private fun buildPanel(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 0)
            background = roundedBg(0xF012121A.toInt(), dpF(20f), 0xFF7C4DFF.toInt(), dp(1))
            elevation = dp(12).toFloat()
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dpF(20f))
                }
            }
        }

        // LEFT: Cat avatar + name (rounded rectangle style)
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(16), dp(10), dp(16))
            layoutParams = LinearLayout.LayoutParams(dp(96), ViewGroup.LayoutParams.MATCH_PARENT)
            background = roundedBg(0xFF1A1A24.toInt(), 0f)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val avatar = ImageView(this).apply {
            setImageResource(R.drawable.avatar_cat)
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(68), dp(68)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, o: Outline) {
                    o.setOval(0, 0, view.width, view.height)
                }
            }
            clipToOutline = true
            elevation = dp(6).toFloat()
        }
        left.addView(avatar)

        left.addView(TextView(this).apply {
            text = "VELKA"
            setTextColor(0xFFB388FF.toInt())
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        })
        left.addView(TextView(this).apply {
            text = "VISUAL"
            setTextColor(0xFF9A9AB0.toInt())
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        })

        // Decorative forest thumbnail under name (3rd photo)
        val forest = ImageView(this).apply {
            setImageResource(R.drawable.menu_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(72), dp(48)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(6)
            }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, o: Outline) {
                    o.setRoundRect(0, 0, view.width, view.height, dpF(8f))
                }
            }
            clipToOutline = true
            alpha = 0.85f
        }
        left.addView(forest)

        // CENTER content
        val contentArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(dp(12), dp(12), dp(8), dp(12))
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleRow.addView(TextView(this).apply {
            text = "Velka Visual"
            setTextColor(0xFFE0D0FF.toInt())
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        contentArea.addView(titleRow)

        val contentContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        contentArea.addView(contentContainer)

        // RIGHT tabs strip
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(14), dp(10), dp(14))
            layoutParams = LinearLayout.LayoutParams(dp(78), ViewGroup.LayoutParams.MATCH_PARENT)
            background = roundedBg(0xFF181822.toInt(), 0f)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val tabNames = listOf("Visual", "Combat", "Misc", "Settings")
        val tabViews = mutableListOf<TextView>()

        fun selectTab(idx: Int) {
            currentTab = idx
            tabViews.forEachIndexed { i, tv ->
                if (i == idx) {
                    tv.setTextColor(0xFFB388FF.toInt())
                    tv.background = roundedBg(0x33B388FF, dpF(10f))
                    tv.setTypeface(null, Typeface.BOLD)
                } else {
                    tv.setTextColor(0xFF8888A0.toInt())
                    tv.background = null
                    tv.setTypeface(null, Typeface.NORMAL)
                }
            }
            contentContainer.removeAllViews()
            contentContainer.addView(buildTabContent(idx))
        }

        tabNames.forEachIndexed { i, name ->
            val tv = TextView(this).apply {
                text = name
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(6), dp(10), dp(6), dp(10))
                setTextColor(if (i == 0) 0xFFB388FF.toInt() else 0xFF8888A0.toInt())
                if (i == 0) {
                    background = roundedBg(0x33B388FF, dpF(10f))
                    setTypeface(null, Typeface.BOLD)
                }
                setOnClickListener {
                    // smooth fade of content
                    contentContainer.animate().alpha(0f).setDuration(90).withEndAction {
                        selectTab(i)
                        contentContainer.alpha = 0f
                        contentContainer.animate().alpha(1f).setDuration(140).start()
                    }.start()
                }
            }
            tabViews.add(tv)
            tabs.addView(tv)
            if (i < tabNames.lastIndex) {
                tabs.addView(View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(36), dp(1)).apply {
                        topMargin = dp(4); bottomMargin = dp(4); gravity = Gravity.CENTER_HORIZONTAL
                    }
                    setBackgroundColor(0x22FFFFFF)
                })
            }
        }

        // Close button at bottom of tabs
        tabs.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(1, 0, 1f)
        })
        val closeBtn = TextView(this).apply {
            text = "✕"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFFFF6B6B.toInt())
            setPadding(dp(8), dp(10), dp(8), dp(10))
            setOnClickListener { togglePanel() }
        }
        tabs.addView(closeBtn)

        // Assemble: LEFT avatar | CENTER content | RIGHT tabs
        root.addView(left)
        root.addView(contentArea)
        root.addView(tabs)

        // Initial content
        contentContainer.addView(buildTabContent(0))

        return root
    }

    private fun buildTabContent(tab: Int): View {
        val scroll = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(280)
            )
            isVerticalScrollBarEnabled = false
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, dp(4), 0)
        }

        when (tab) {
            0 -> { // Visual: real screen effects + pointer to in-game effects
                val f = fx
                col.addView(sectionTitle("Screen effects"))
                col.addView(makeSwitchRow("Ambience", f?.tintOn == true) { on -> fx?.tintOn = on })
                col.addView(makeSwitchRow("Fog", f?.fogOn == true) { on -> fx?.fogOn = on })
                col.addView(makeSwitchRow("SkyShader", f?.skyOn == true) { on -> fx?.skyOn = on })
                col.addView(makeSwitchRow("Vignette", f?.vignetteOn == true) { on -> fx?.vignetteOn = on })
                col.addView(makeSwitchRow("AspectRatio (bars)", f?.barsOn == true) { on -> fx?.barsOn = on })
                col.addView(label("Strength"))
                col.addView(SeekBar(this).apply {
                    max = 100
                    progress = ((f?.strength ?: 0.3f) * 100).toInt()
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                            fx?.strength = p / 100f
                        }
                        override fun onStartTrackingTouch(s: SeekBar?) {}
                        override fun onStopTrackingTouch(s: SeekBar?) {}
                    })
                })
                col.addView(Button(this, "Change tint color") {
                    tintIdx = (tintIdx + 1) % tintColors.size
                    fx?.tintColor = tintColors[tintIdx]
                })
                col.addView(sectionTitle("In-game effects"))
                col.addView(TextView(this).apply {
                    text = "Hit Swirl / Ring / Halo / Slash, Hit Bubble, Target Outline, Aura, " +
                        "Jump Circle, Trails and Night Vision run inside the world (add-on).\n\n" +
                        "Open their menu: use a clock in the game, or type /scriptevent velka:menu"
                    setTextColor(0xFF9A9AB0.toInt())
                    textSize = 12f
                    setLineSpacing(dpF(3f), 1f)
                    setPadding(0, dp(2), 0, dp(8))
                })
            }
            1 -> { // Combat
                col.addView(sectionTitle("Combat"))
                col.addView(TextView(this).apply {
                    text = "Hit effects (swirl, bubble, outline, jump circle) are configured in-game: use a clock."
                    setTextColor(0xFF9A9AB0.toInt())
                    textSize = 12f
                    setLineSpacing(dpF(3f), 1f)
                    setPadding(0, 0, 0, dp(6))
                })
                col.addView(sectionTitle("Crosshair"))
                col.addView(makeSwitchRow("Crosshair", crossOn) { on ->
                    crossOn = on
                    updateCrosshair()
                })
                col.addView(label("Size"))
                col.addView(SeekBar(this).apply {
                    max = 80
                    progress = crossSize - 20
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                            crossSize = p + 20
                            updateCrosshair()
                        }
                        override fun onStartTrackingTouch(s: SeekBar?) {}
                        override fun onStopTrackingTouch(s: SeekBar?) {}
                    })
                })
                col.addView(Button(this, "Change Color") {
                    colorIdx = (colorIdx + 1) % colors.size
                    cross?.color = colors[colorIdx]
                })
            }
            2 -> { // Misc
                col.addView(sectionTitle("Utilities"))
                // Stopwatch
                val t = label(format(elapsed)).apply {
                    textSize = 24f
                    gravity = Gravity.CENTER
                    setPadding(0, dp(8), 0, dp(8))
                    setTextColor(0xFFB388FF.toInt())
                }
                timeText = t
                col.addView(t)

                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, 0, 0, dp(8))
                }
                row.addView(Button(this, if (running) "Stop" else "Start") {
                    if (running) {
                        elapsed = SystemClock.elapsedRealtime() - startMs
                        running = false
                    } else {
                        startMs = SystemClock.elapsedRealtime() - elapsed
                        running = true
                        tick()
                    }
                    (it as TextView).text = if (running) "Stop" else "Start"
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(6) })

                row.addView(Button(this, "Reset") {
                    running = false
                    elapsed = 0
                    timeText?.text = format(0)
                    (row.getChildAt(0) as? TextView)?.text = "Start"
                }, LinearLayout.LayoutParams(0, dp(40), 1f))
                col.addView(row)
            }
            3 -> { // Settings
                col.addView(sectionTitle("Settings"))
                col.addView(TextView(this).apply {
                    text = "Velka Visual\nBedrock overlay client\nStyle inspired by Atlas"
                    setTextColor(0xFF9A9AB0.toInt())
                    textSize = 13f
                    setPadding(0, dp(4), 0, dp(12))
                    setLineSpacing(dpF(3f), 1f)
                })
                col.addView(Button(this, "Disable Client") {
                    stopSelf()
                })
            }
        }

        scroll.addView(col)
        return scroll
    }

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        setTextColor(0xFFB388FF.toInt())
        textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(4))
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(0xFFCCCCDD.toInt())
        textSize = 12f
        setPadding(0, dp(4), 0, dp(2))
    }

    private fun makeSwitchRow(name: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
            background = roundedBg(0x22FFFFFF, dpF(10f))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(5) }
        }
        row.addView(TextView(this).apply {
            text = name
            setTextColor(Color.WHITE)
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.addView(Switch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, on -> onChange(on) }
        })
        return row
    }

    private fun Button(ctx: android.content.Context, text: String, onClick: (View) -> Unit): TextView {
        return TextView(ctx).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
            background = roundedBg(0xFF7C4DFF.toInt(), dpF(12f))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener(onClick)
        }
    }

    private fun tick() {
        if (!running) return
        timeText?.text = format(SystemClock.elapsedRealtime() - startMs)
        handler.postDelayed({ tick() }, 80)
    }

    private fun format(ms: Long): String {
        val s = ms / 1000
        return "%02d:%02d.%d".format(s / 60, s % 60, (ms % 1000) / 100)
    }

    private fun updateCrosshair() {
        if (!crossOn) {
            cross?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            cross = null; crossLp = null
            return
        }
        val px = dp(crossSize)
        val c = cross
        if (c == null) {
            val v = CrosshairView(this).apply { color = colors[colorIdx] }
            val lp = overlayParams(px, px, false).apply { gravity = Gravity.CENTER }
            wm.addView(v, lp)
            cross = v; crossLp = lp
        } else {
            crossLp?.let {
                it.width = px; it.height = px
                try { wm.updateViewLayout(c, it) } catch (_: Exception) {}
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cross?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        fx?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
