package com.pulse.launcher

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : AppCompatActivity() {

    private val mcPackage = "com.mojang.minecraftpe"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<Button>(R.id.btnInstall).setOnClickListener { installPack() }
        findViewById<Button>(R.id.btnLaunch).setOnClickListener { launch() }
    }

    private fun launch() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow «Display over other apps» then press LAUNCH again")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mc = packageManager.getLaunchIntentForPackage(mcPackage)
        if (mc == null) {
            toast("Minecraft not found")
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        startActivity(mc)
    }

    private fun installPack() {
        try {
            val file = File(cacheDir, "VelkaVisual.mcaddon")
            assets.open("VelkaVisual.mcaddon").use { i -> file.outputStream().use { i.copyTo(it) } }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/octet-stream")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startActivity(Intent(view).setPackage(mcPackage))
            } catch (e: ActivityNotFoundException) {
                startActivity(Intent.createChooser(view, "Open with Minecraft"))
            }
        } catch (e: Exception) {
            toast("Install failed: ${e.message ?: "is Minecraft installed?"}")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
