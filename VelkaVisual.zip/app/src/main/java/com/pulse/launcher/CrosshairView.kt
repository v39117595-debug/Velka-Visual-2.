package com.pulse.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class CrosshairView(context: Context) : View(context) {
    var color: Int = 0xFFFFFFFF.toInt()
        set(v) { field = v; invalidate() }

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 4f }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 8f; this.color = 0xFF000000.toInt() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val gap = width * 0.12f
        val len = width / 2f - 4f
        line.color = color
        for (p in listOf(outline, line)) {
            c.drawLine(cx - len, cy, cx - gap, cy, p)
            c.drawLine(cx + gap, cy, cx + len, cy, p)
            c.drawLine(cx, cy - len, cx, cy - gap, p)
            c.drawLine(cx, cy + gap, cx, cy + len, p)
        }
    }
}
