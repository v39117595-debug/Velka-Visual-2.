package com.pulse.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import kotlin.math.max

/**
 * Full-screen, non-touchable layer drawn over the game.
 * Everything here is real (drawn by the app), not a placeholder.
 */
class ScreenFxView(context: Context) : View(context) {

    var tintOn: Boolean = false
        set(v) { field = v; refresh() }
    var fogOn: Boolean = false
        set(v) { field = v; refresh() }
    var skyOn: Boolean = false
        set(v) { field = v; refresh() }
    var vignetteOn: Boolean = false
        set(v) { field = v; refresh() }
    var barsOn: Boolean = false
        set(v) { field = v; refresh() }
    var tintColor: Int = 0xFFB388FF.toInt()
        set(v) { field = v; refresh() }

    /** 0..1 */
    var strength: Float = 0.3f
        set(v) { field = v; refresh() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun refresh() {
        visibility = if (tintOn || fogOn || skyOn || vignetteOn || barsOn) VISIBLE else GONE
        invalidate()
    }

    private fun withA(color: Int, a: Float): Int =
        Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(color), Color.green(color), Color.blue(color))

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (tintOn) {
            paint.shader = null
            paint.color = withA(tintColor, strength * 0.6f)
            c.drawRect(0f, 0f, w, h, paint)
        }
        if (skyOn) {
            paint.shader = LinearGradient(
                0f, 0f, 0f, h * 0.55f,
                withA(tintColor, strength * 1.2f), withA(tintColor, 0f), Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w, h * 0.55f, paint)
        }
        if (fogOn) {
            val top = h * 0.30f
            val bot = h * 0.80f
            val mid = (top + bot) / 2f
            val white = 0xFFFFFFFF.toInt()
            paint.shader = LinearGradient(0f, top, 0f, mid, withA(white, 0f), withA(white, strength * 1.1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, top, w, mid, paint)
            paint.shader = LinearGradient(0f, mid, 0f, bot, withA(white, strength * 1.1f), withA(white, 0f), Shader.TileMode.CLAMP)
            c.drawRect(0f, mid, w, bot, paint)
        }
        if (vignetteOn) {
            val r = max(w, h) * 0.75f
            paint.shader = RadialGradient(
                w / 2f, h / 2f, r,
                intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, withA(Color.BLACK, strength * 1.8f)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w, h, paint)
        }
        if (barsOn) {
            paint.shader = null
            paint.color = Color.BLACK
            val bar = w * 0.1f
            c.drawRect(0f, 0f, bar, h, paint)
            c.drawRect(w - bar, 0f, w, h, paint)
        }
        paint.shader = null
    }
}
